function findMinimalHiDim(model, ncores, maxred)

% 630 limit

load(['solutions' model filesep 'totalChromosome.mat'])
totalChromosome = totalChromosome(:,1:end-2);
[N,M] = size(totalChromosome);
totalChromosome1 = logical(totalChromosome(:,1:M-2));
totalChromosome2 = totalChromosome(:,M-1:M);
save(['solutions' model filesep 'totalChromosome_split.mat'],'totalChromosome1','totalChromosome2','-v7.3');
clear totalChromosome1 totalChromosome2
totalChromosome = totalChromosome(totalChromosome(:,M)>=629,:);
totalChromosome = sortrows(totalChromosome,-M);
[N,~] = size(totalChromosome);
index = true(N,1);
V = M - 2;
if ~exist(['solutions' model filesep 'minimalSolutionsOld.mat'],'file')
    delete(gcp('nocreate'))
    parpool('local',ncores)
    for j = max(totalChromosome(:,M)):-1:630
        disp(j)
        ii = find(totalChromosome(:,M) == j & index);
        jj = find(totalChromosome(:,M) == j-1);
        if ~isempty(jj)
            domMatrix = logical(sparse(length(ii),length(jj)));
            totalChromosometemp = totalChromosome(ii,:);
            temp = totalChromosome(jj,1:V);
            parfor i = 1:length(ii)
%                 x = totalChromosome(ii(i),:);
                x = totalChromosometemp(i,:);
                D = pdist2(x(1:V),temp,'cityblock');
                domMatrix(i,:) = D==1;
            end
            for i = 1:length(jj)
                if any(domMatrix(:,i))
                    index(jj(i)) = false;
                end
            end
        end
    end
    minSol = totalChromosome(index,:);
    save(['solutions' model filesep 'minimalSolutionsOld.mat'],'minSol','-v7.3')
else
    load(['solutions' model filesep 'minimalSolutionsOld.mat']);
end

delete(gcp('nocreate'))
parpool('local',ncores)

temp = load(['solutions' model filesep 'fbamodel.mat']);
fbamodel = temp.fbamodel;
f = fitnessFunctionBoundsSA(zeros(1,fbamodel.ngenes),fbamodel);
utopianBio = f(1);
% load('utopianBio.mat');
V = fbamodel.ngenes;
M = size(minSol,1);
I = true(M,1);
parfor i = 1:M
%     tic
%     if ~isempty(exhaustive1LevelBreak(minSol(i,1:V), fbamodel, utopianBio))
    if ~isempty(exhaustive1LevelBreak(minSol(i,1:V), fbamodel, utopianBio, maxred))
        I(i) = false;
    end
%     clc
%     fprintf('%.2f %% completed\n',100*i/M);
%     toc
end
minSol = minSol(I,:);
save(['solutions' model filesep 'minimalSolutions.mat'],'minSol','-v7.3')

% t = 1:fbamodel.ngenes;
% for i = 1:size(minSol,1)
%     t = intersect(t,find(minSol(i,1:fbamodel.ngenes)),'stable');
% end

