%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Pipeline for the creation of minimal metabolic networks from
%%% Genome-Scale models of metabolism
%%% Tested on Matlab R2020a
%%% Requires a running version of Gurobi (tested on version 8 and 9)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PARAMETERS
restart = false;                            % set true if have to complete an interrupted optimization
pop = 100;                                  % population for the optimization
gen = 5000;                                 % maximum number of generation
ncores = 4;                                 % number of concurrent threads to be used for optimization and post processing (use Parallel Computing Toolbox, if not available set as 0)
model = 'fbamodel_yeastGEM_YPD_new';        % mat file of the FBA model to use (located in the 'model' folder)
optMode = 'FBA';                            % mode used (FBA only)
flagEssGenes = true;                        % true if the model contains the field 'essentialGenes' and you want to exclude them from optimization
flagEssCouples = false;                     % true if the model contains the field 'essentialGenes' and you want to exclude them from optimization
flagCOBRA = false;                          % true if the model is in COBRA format (the fields lb, ub, c and rules will be renamed)
maxred = 0.01;                              % allowed threshold on predicted GR (set on 1%)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% OUTPUT
%%% All the results are saved in a folder named 'solutions*NAME OF THE MODEL*'
%%% When all the post processing ends, there will be 12 files, see README
%%% for a description.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rng('shuffle')
addpath('classes');
addpath(genpath('utils'));
% addpath('gurobi matlab PATH')             % Add Gurobi path if needed

fbamodel = loadFBAmodel(['model' filesep model], flagEssGenes, flagEssCouples, flagCOBRA);

if ~restart
    %Directory in which results will be stored
    results_folder = ['solutions', model, filesep, optMode, filesep];
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%Building the Optimizer Object%%%
    GDMOobj = GDMOopt(pop,gen,fbamodel,optMode,results_folder,ncores,maxred,0,true,10);
else
    load(['solutions' model filesep optMode filesep 'GDMOobj.mat']);
    GDMOobj.gen = gen;
    GDMOobj.ncores = ncores;
    GDMOobj.results_folder = ['solutions' model filesep optMode filesep];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%Running the Optimization%%%%
GDMOobj = GDMOobj.runOptimiser();

rmpath('classes');
rmpath(genpath('utils'));
fbamodel = struct(fbamodel);
save(['solutions' model filesep 'fbamodel'], 'fbamodel');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%Running Post Process Analysis%%%
addpath('post')

saveTotalChromosome(model, optMode, gen, ncores);
findMinimal(model, ncores, maxred)
matrixReac(model,ncores)
matrixReacParsimonious(model,ncores)
savevMinSol(model,ncores)
minSolsCompGenes(model)

solutions = struct;
for i = 1:gen
    load(['solutions' model filesep optMode filesep 'solution' num2str(i)],'chromosome');
    solutions.(['s' num2str(i)]) = chromosome;
end
save(['solutions' model filesep 'solutions.mat'],'solutions','-v7.3')
movefile(['solutions' model filesep optMode filesep 'GDMOobj.mat'],['solutions' model filesep 'GDMOobj.mat']);
rmdir(['solutions' model filesep optMode], 's')

rmpath('post')
