function [ evenIdxs , oddIdxs ] = getFFidxs( resObj )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

[evenIdxs , oddIdxs] = getEvenOddIdxs(resObj.M);

end

